S. RITHANYA — DEVELOPER PORTFOLIO

OPEN LOCALLY
1. Unzip the folder.
2. Double-click index.html to open it in your browser.

PUBLISH WITH GITHUB PAGES
1. Create a public GitHub repository, e.g. rithanya-portfolio.
2. Upload index.html, style.css, and script.js to the repository root.
3. Go to Settings > Pages > Build and deployment.
4. Select Deploy from a branch, main, / (root), then Save.
5. Wait for GitHub Pages to publish your website.

CUSTOMIZE
- Edit index.html to update text, email, or add GitHub/LinkedIn links.
- Edit style.css for colors and layout.
- Edit script.js for interactions.

NOTES
- Project descriptions are based on information provided in your resume and conversations.
- No GitHub/LinkedIn links or screenshots were invented.
- The website uses Google Fonts when online and system fonts when offline.
